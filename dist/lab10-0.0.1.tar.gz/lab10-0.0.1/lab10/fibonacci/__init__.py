"""
Collection of fibonacci methods and functions
"""
from . import recursion

__all__ = [
    'recursion'
]
