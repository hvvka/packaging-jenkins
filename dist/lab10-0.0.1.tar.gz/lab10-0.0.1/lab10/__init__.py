"""
Lab 10
"""

__version__ = '0.0.1'
__author__ = 'Hanna'

__maintainers__ = [
    'Hanna'
]

__contributors__ = [
    "Hanna"
]

__all__ = [
    'fibonacci',
    'math',
    'sorting',
    'strings'
]
