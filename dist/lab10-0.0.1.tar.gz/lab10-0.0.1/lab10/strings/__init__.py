"""
Collection of string methods and functions
"""
from . import anagram
from . import palindrome

__all__ = [
    'anagram',
    'palindrome'
]
